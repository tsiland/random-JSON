package csi403;

import java.util.ArrayList;

public class SubInJSON extends InList {
    private ArrayList smart;

    public SubInJSON(){}

    public ArrayList getSmart() {
        return smart;
    }

    public void setSmart(ArrayList smart) {
        this.smart = smart;
    }
}
//private String cmd;
//private String name;
//private int pri;